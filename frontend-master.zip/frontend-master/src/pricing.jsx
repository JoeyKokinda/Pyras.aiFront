import React from "react";
import Navbar from "./navbar";

const Pricing = () => {
    return (
        <>
            <Navbar />

        <div className="home-page">
            <div class="home-content">
                <a href="#" class="button1">
                <span>Pricing</span>
                <i></i>
                </a>
            </div>
        </div>

        </>
    );
};

export default Pricing;