import React from "react";
import Navbar from "./navbar";

const Rent = () => {
    return (
        <>
            <Navbar />

        <div className="home-page">
            <div class="home-content">
                <a href="#" class="button1">
                <span>Rent</span>
                <i></i>
                </a>
            </div>
        </div>

        </>
    );
};

export default Rent;