import React from "react";
import Navbar from "./navbar";

const Contact = () => {
    return (
        <>
            <Navbar />

        <div className="home-page">
            <div class="home-content">
                <a href="#" class="button1">
                <span>Contact</span>
                <i></i>
                </a>
            </div>
        </div>

        </>
    );
};

export default Contact;